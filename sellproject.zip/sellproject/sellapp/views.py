import json
from notificationsapp.models import BroadcastNotification
from django.http import request
from django.shortcuts import get_object_or_404, render,redirect,HttpResponse
from sellapp.forms import *
from accounts.forms import ProfileUpdateForm, UserUpdateForm
from django.contrib import messages
from sellapp.models import *
from django.utils import timezone
from django.core.paginator import Paginator
from django.contrib import messages
from django.core.mail import send_mail
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import CreateView
from django.conf import settings 
from django.views.generic.base import View
from sellproject.settings import EMAIL_HOST_USER
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.http import HttpResponse, JsonResponse




# Create your views here.

def index(request):
    products = Product.objects.all()
    
    # search code
    item_name = request.GET.get('item_name')
    if item_name != '' and item_name is not None:
        products = products.filter(name__icontains=item_name) 
                
    # paginator code
    paginator = Paginator(products,4)
    page = request.GET.get('page')
    products = paginator.get_page(page)
    
    room_name = request.user.username         
    return render(request,'sellapp/index.html',{'products':products,'room_name':room_name})


# add product view
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST,request.FILES)
        if form.is_valid():
            print("True")
            form_save = form.save(commit=False)
            form_save.user_name = request.user
            form_save.save()
            print("Data saved Successfully")
            messages.success(request,"Product is  added successfully...")
            return redirect('/')            
        else:
            print("Not working")
            messages.info(request,"Product is not added,Try again")
    else:
        form = ProductForm()
    return render(request,'sellapp/add_product.html',{'form':form})

# logged user products
def my_product(request):
    products = Product.objects.all()
    return render(request,'sellapp/my_product.html',{'products':products})

# product post user description view
def my_product_desc(request,pk):
    product = Product.objects.get(pk=pk)
    return render(request,'sellapp/my_product_desc.html',{'product':product})

# product description view    
def product_desc(request,pk):
    product = Product.objects.get(pk=pk)
    return render(request,'sellapp/product_desc.html',{'product':product}) 
   
# delete product view
def delete_product(request,pk):
    product = Product.objects.get(pk=pk)
    product.delete()
    messages.success(request,"product has been deleted")
    return redirect('/')

# edit product view
def edit_product(request,pk):
    product = Product.objects.get(pk=pk)
    editproduct = EditproductForm(instance=product)
    if request.method == 'POST':
        form = EditproductForm(request.POST,instance=product)
        if form.is_valid():
            form.save()
            messages.success(request,'product details has been updated')
            return redirect('/')        
    return render(request,'sellapp/edit_product.html',{'edit_product':editproduct})

# product inquiry view
def product_inquiry(request,pk): 
    product = Product.objects.get(pk=pk)     
    return render(request,'sellapp/product_inquiry.html',{'product':product})
    
# buy product view
class Buyview(View):
    def post(self,request,*args,**kwargs):
        if request.method == "POST":
            pk = self.kwargs.get('pk')
            products = Product.objects.get(pk=pk)
            
            seller_name = Product.objects.get(pk=pk)
            seller = seller_name.user_name
            print("hi",seller.email)
            #print("hi",seller.username)
            buyer_price = request.POST['buyer_price']
            buyer_name = request.user
            buyer_phone = Profile.objects.get(user=request.user).phone_field
            buyer_email= request.user.email
            
            Buyer(buyer_name=buyer_name,buyer_phone=buyer_phone,buyer_price=buyer_price,product_name=products,buyer_email=buyer_email,seller=seller).save()
            #User(buyer_name=buyer_name,buyer_phone=buyer_phone).save(commit=False)
            
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                "notification_%s"%seller.username,
                {
                    'type': 'send_notification',
                    'message': "a user has send a inquiry for your product."
                }
            )
            notification = BroadcastNotification.objects.create(message= f'a user has send a inquiry for your product.', sent= True, to= seller )
            notification.save()
            
           # Emailid  
            Subject = 'Buyer Inquiry Mail'
            Message = f'intrested:a user has send a inquiry for your product. '
            Recepient = str(seller.email)
            send_mail(Subject, Message, EMAIL_HOST_USER, [Recepient], fail_silently=False)
            messages.success(request, "sucessfully sent a inquiry mail")   
        return redirect("/")


# buyer list view
def inquiry_details(request,pk): 
    product_details_inquiry = Product.objects.get(pk=pk)
    # buyers = Buyer.objects.get(product_name=product_details_inquiry)
    inquiry = Buyer.objects.filter(seller=request.user,product_name=product_details_inquiry)         
    # print(inquiry)    
    return render(request,'sellapp/inquiry_details.html',{'inquiry':inquiry,'product_details_inquiry':product_details_inquiry})

# pending view
def accept(request, pk):
    approve = get_object_or_404(Buyer, pk=pk)
    approve.order_status = True
    approve.save(update_fields=['status'])
    buyer = approve.buyer_name
    # return render(request, '/')
    
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
    "notification_%s"%buyer.username,
    {
    'type': 'send_notification',
    'message': "seller accepted your inquiry."
    }
    )
    
    # Emailid  
    Subject = 'seller Response Mail'
    Message = f'seller accepted your request.contact the seller using the number in the website product description....Thank You for using BuyNow... '
    Recepient = str(approve.buyer_email)
    send_mail(Subject, Message, EMAIL_HOST_USER, [Recepient], fail_silently=False)
    messages.success(request, "sucessfully sent a accepted mail to buyer")  
    return redirect("/")


# seller reject view
def reject(request, pk):
    notapprove = get_object_or_404(Buyer, pk=pk)
    notapprove.order_status = True
    notapprove.save(update_fields=['status'])
    buyer = notapprove.buyer_name
    # return render(request, '/')
    
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
    "notification_%s"%buyer.username,
    {
    'type': 'send_notification',
    'message': "seller rejected your inquiry."
    }
    )
    
    # Emailid  
    Subject = 'seller Response Mail'
    Message = f'seller rejected your request.Thank You for using BuyNow... '
    Recepient = str(notapprove.buyer_email)
    send_mail(Subject, Message, EMAIL_HOST_USER, [Recepient], fail_silently=False)
    messages.success(request, "sucessfully sent a rejected mail to buyer")  
    return redirect("/")


# notificatio view
def test(request):
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        "notification_%s"%request.user.username,
        {
            'type': 'send_notification',
            'message': "Notification"
        }
    )
    return HttpResponse("Done")

# chatroom
def chatroom(request):
    return render(request, 'sellapp/firstroom.html')

def room(request, room):
    username = request.GET.get('username')
    room_details = Room.objects.get(name=room)
    return render(request, 'sellapp/room.html', {
        'username': username,
        'room': room,
        'room_details': room_details
    })
 
    
def checkview(request):
    room = request.POST['room_name']
    username = request.POST['username']
    if Room.objects.filter(name=room).exists():
        return redirect('/'+room+'/?username='+username)
    else:
        new_room = Room.objects.create(name=room)
        new_room.save()
        return redirect('/'+room+'/?username='+username)
    
def send(request):
    message = request.POST['message']
    username = request.POST['username']
    room_id = request.POST['room_id']
    new_message = Message.objects.create(value=message, user=username, room=room_id)
    new_message.save()
    return HttpResponse('Message sent successfully')

def getMessages(request, room):
    room_details = Room.objects.get(name=room)
    messages = Message.objects.filter(room=room_details.id)
    return JsonResponse({"messages":list(messages.values())})
