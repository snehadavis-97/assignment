# from accounts.models import Category, Product
from django.contrib import admin
#from accounts.models import Profile
from sellapp.models import *

# admin.site.register(Profile)
admin.site.register(Category)
admin.site.register(Product)
admin.site.register(Buyer)
admin.site.register(Room)
admin.site.register(Message)
# admin.site.register(OrderItem)
