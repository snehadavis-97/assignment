from django.db.models import fields
from sellapp.models import  Product
from django import forms
from accounts.models import *
from .forms import *

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'
        exclude = ['user_name']
        widgets = {
            # 'user_name':forms.TextInput(attrs={'class':'form_control'}),
            'name':forms.TextInput(attrs={'class':'form_control'}),
            'category':forms.Select(attrs={'class':'form_control'}),
            'desc':forms.Textarea(attrs={'class':'form_control'}),
            'price':forms.NumberInput(attrs={'class':'form_control'}),
            'product_available_count':forms.NumberInput(attrs={'class':'form_control'}),
            'img':forms.FileInput(attrs={'class':'form_control'}),
        }
        
        
class EditproductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'    
        
 
   