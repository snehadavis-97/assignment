from django.db.models.deletion import CASCADE
from accounts.models import Profile
from django.db import models
from typing import Reversible
from django.contrib.auth.models import User
from django.db.models.fields import reverse_related
from datetime import datetime


    
class Category(models.Model):
    category_name = models.CharField(max_length=200)
    def __str__(self):
        return self.category_name
    
              
class Product(models.Model):
    user_name = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    category = models.ForeignKey('Category',on_delete=models.CASCADE)
    desc = models.TextField()
    # location = models.TextField()
    price = models.FloatField(default=0.0)
    product_postdate = models.DateField(default=datetime.now)
    img = models.ImageField(upload_to='images/')
    # date = models.DateTimeField(auto_now_add=True,null=True)

    
    def __str__(self):
        return self.name
        
    
class Buyer(models.Model):
    buyer_name = models.ForeignKey(User, on_delete=models.CASCADE,related_name='buyer')
    seller = models.ForeignKey(User, on_delete=models.CASCADE,related_name='seller')
    #buyer_name = models.CharField(max_length=100)
    buyer_phone = models.CharField(max_length=12,blank=False)
    buyer_email = models.EmailField(max_length = 254)
    product_name = models.ForeignKey(Product, on_delete=models.CASCADE)
    buyer_price = models.PositiveIntegerField()
    status = models.BooleanField(default=False)
    # product_id = models.PositiveIntegerField()
    
    # def __str__(self):
    #     return self.product_name
 
 
#chatroom   
class Room(models.Model):
    name = models.CharField(max_length=1000)
        
class Message(models.Model):
    value = models.CharField(max_length=1000000)
    date = models.DateTimeField(default=datetime.now, blank=True)
    user = models.CharField(max_length=1000000)
    room = models.CharField(max_length=1000000)    
       
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

