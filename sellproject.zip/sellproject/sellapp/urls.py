#from sellapp.forms import InquiryForm
from accounts.views import ProfileUpdateView
from django.urls import path
from sellapp import views
from sellapp.views import Buyview

urlpatterns = [
    path('',views.index,name='index'),
    path('test/',views.test,name='test'), # notification
    path('chatroom',views.chatroom,name='chatroom'),# chat room
    path('<str:room>/', views.room, name='room'),
    path('checkview', views.checkview, name='checkview'),
    path('send', views.send, name='send'),
    path('getMessages/<str:room>/', views.getMessages, name='getMessages'),

    
    path('add_product',views.add_product,name="add_product"),  
    path('product_desc/<pk>',views.product_desc,name='product_desc'),
    # path('add_to-cart/<pk>',views.add_to_cart,name="add_to_cart"),
    path('my_product_desc/delete_product/<pk>',views.delete_product,name='delete_product'),
    path('my_product_desc/edit_product/<pk>',views.edit_product,name='edit_product'),
    path('my_product',views.my_product,name="my_product"),
    path('my_product_desc/<pk>',views.my_product_desc,name='my_product_desc'),
    path('product_inquiry/<pk>',views.product_inquiry,name="product_inquiry"),
    path('buyview/<int:pk>',Buyview.as_view(),name="buyview"),
    path('inquiry_details/<pk>',views.inquiry_details,name="inquiry_details"),
    path('accept/<pk>',views.accept,name="accept"),
    path('reject/<pk>',views.reject,name="reject"),
    
    
    
]
