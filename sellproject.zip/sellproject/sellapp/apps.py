from django.apps import AppConfig


class SellappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sellapp'
