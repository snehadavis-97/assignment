# from .models import Profile
from django.views.generic.base import View
from .models import Profile
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from sellapp.models import *
from django.contrib import messages
import uuid  # confirmation mail
from django.conf import settings # confirmation mail
from django.core.mail import send_mail # confirmation mail
from django.contrib.auth import authenticate,login,logout
#from django.contrib.auth.decorators import login_required
from accounts.forms import *
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import CreateView

# Create your views here.
#@login_required


# login view

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user_obj = User.objects.filter(username = username).first()
        if user_obj is None:
            messages.success(request,"User is not found!")
            return redirect('user_login')
        profile_obj = Profile.objects.filter(user = user_obj).first()
        
        if not profile_obj.is_verified:
            messages.success(request,"Profile is not verified check your mail...")
            return redirect('user_login') 
        user = authenticate(username = username , password = password)
        
        if user is None:
            messages.success(request, 'Wrong password.')
            return redirect('user_login')
        login(request , user)
        return redirect('/')
    return render(request, 'accounts/login.html')
            

# register view 

def user_register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        phone_field = request.POST.get('phone_field')
        password = request.POST.get('password')
        # confirm_password = request.POST.get('confirm_password')
        print(password)
        try:
        
            if User.objects.filter(username=username).first():
                messages.success(request,"Username already exists!")
                return redirect('user_register')
        
            
            user_obj = User.objects.create(username=username,email=email)
            user_obj.set_password(password)
            user_obj.save()
            auth_token = str(uuid.uuid4())
            profile_obj = Profile.objects.create(user = user_obj, auth_token = auth_token,phone_field = phone_field)
            profile_obj.save()
            send_mail_after_registration(email, auth_token)
            return redirect('/accounts/token_send')
        except Exception as e:
            print(e) 
        
    return render(request,'accounts/register.html')


# email verification
def success(request):
    return render(request,'accounts/success.html')


def token_send(request):
    return render(request,'accounts/token_send.html')



def verify(request , auth_token):
    try:
        profile_obj = Profile.objects.filter(auth_token = auth_token).first()
        
        if profile_obj:
            if profile_obj.is_verified:
                messages.success(request, 'Your account is already verified.')
                return redirect('/accounts/user_login')
            profile_obj.is_verified = True
            profile_obj.save()
            messages.success(request, 'Your account has been verified.')
            return redirect('/accounts/user_login')
        else:
            return redirect('/error')
    except Exception as e:
        print(e)
        return redirect('/')
        
           
def error_page(request):
    return  render(request ,'accounts/error.html')

    
def send_mail_after_registration(email,token):
    subject = "your accounts need to be verified"
    message = f'paste this link to verify your account http://127.0.0.1:8000/accounts/verify/{token}'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, email_from, recipient_list)


 # logout view     
def user_logout(request):
    logout(request)
    return redirect('/')

   
def user_profile(request):
    return  render(request ,'accounts/profile.html')   


class ProfileUpdateView(LoginRequiredMixin, CreateView):
    template_name= 'accounts/update_profile.html'
    form_class = ProfileUpdateForm
    
    def get(self, request):
        getdetails = Profile.objects.get(user = request.user)
        userform = UserUpdateForm(instance= request.user)
        detailsform = self.form_class( instance = getdetails)
        context = {'userform': userform, 'detailsform': detailsform}
        return render(request, self.template_name, context)

    def post(self, request):
        # import pdb
        # pdb.set_trace()
        getdetails = Profile.objects.get(user = request.user)
        if request.method == 'POST':
            details_form = self.form_class(request.POST, request.FILES, instance = getdetails)
            userform = UserUpdateForm(request.POST, request.FILES, instance= request.user)
            if userform.is_valid():
                user = userform.save()
                user.save()

            if details_form.is_valid():
                details = details_form.save()
                details.save()
                messages.success(request, 'Profile details updated.')
                return redirect('/')
        else:
            userform = self.form_class(instance = request.user)
            details_form = self.form_class(instance = getdetails)
            
        context = {'detailsform': details_form, 'userform': userform}
        return render(request, self.template_name, context)
 


