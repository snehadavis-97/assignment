from django.conf.urls import include
from django.urls import path
from accounts import views
from .views import *
from django.contrib.auth import views as auth_views # forgott password

urlpatterns = [
    
    # path('home',views.home,name='home'),
    path('user_login',views.user_login,name="user_login"),
    path('user_register',views.user_register,name="user_register"),
    path('user_logout',views.user_logout,name="user_logout"),
    path('success',views.success,name='success'),
    path('token_send/',views.token_send,name='token_send'),
    path('verify/<auth_token>',views.verify,name='verify'),
    path('error' , views.error_page , name="error"),
    path("accounts/", include("django.contrib.auth.urls")), # forgott password
    path('user_profile',views.user_profile,name="user_profile"),
    path('ProfileUpdateView/',ProfileUpdateView.as_view(),name="ProfileUpdateView"),
    
    # forgot password password urls
    path('password_reset', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset_done', auth_views.PasswordResetDoneView.as_view(),name='password_reset_done'),
    path('password_reset_confirm/<slug:uidb64>/<slug:token>/', auth_views.PasswordResetConfirmView.as_view(),name='password_reset_confirm'),
    path('password_reset_complete', auth_views.PasswordResetCompleteView.as_view(),name='password_reset_complete'),
]
