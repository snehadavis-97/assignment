from accounts.models import Profile
#from accounts.models import Location
from django.contrib import admin
from sellapp.models import *

# Register your models here.

admin.site.register(Profile)
# admin.site.register(Category)
# admin.site.register(Product)