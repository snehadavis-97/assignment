This is a django OlxWebsite.

Getting Started with  a folder called sellproject
This project was bootstrapped with the application called sellapp

Available Scripts:

* In the project terminal,first you can create a virtual environment:
               virtualenv -p python3.6 esite
* Then you can activate the environment using:
               source esite/bin/activate
* Install all dependencies:
               pip install -r requirements.txt 
* Apply database migrations:
               python manage.py migrate
* Run the application:
               python manage.py runserver